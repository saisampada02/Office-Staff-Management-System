<?php
session_start();
session_abort();
header(“location:emplogin.html”);
?>
