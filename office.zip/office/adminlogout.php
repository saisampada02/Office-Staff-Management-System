<?php
session_start();
session_abort();
header(“location:adminlogin.html”);
?>
