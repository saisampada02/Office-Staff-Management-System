<?php include 'edashboard.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Task Created </title>
   
</head>
<body>
<main class="main-container" id="main">
        <div class="main-title">
          <h2>Status Updated Successfully</h2>
        </div>
 <script src="js/scripts.js"></script>
               
</body>
</html>
  